
import wvpy

mk_cross_plan(10, 3)
