
import wvpy.util

wvpy.util.mk_cross_plan(10, 3)


