Win Vector LLC tools for converting Python Jupyter to and from Python source files
https://github.com/WinVector/wvpy

Some notes can be found here: https://github.com/WinVector/wvpy
and here: https://win-vector.com/2022/08/20/an-effective-personal-jupyter-data-science-workflow/

Many of the data science functions have been moved to wvu https://github.com/WinVector/wvu


