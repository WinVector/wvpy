__docformat__ = "restructuredtext"
__version__ = "1.0.1"

__doc__ = """
This<https://github.com/WinVector/wvpy> a system for rendering Jupyter notebooks.
"""
