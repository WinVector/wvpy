__docformat__ = "restructuredtext"
__version__ = "1.1.1"

__doc__ = """
<https://github.com/WinVector/wvpy> a system for converting and rendering Jupyter notebooks.
"""
