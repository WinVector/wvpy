Win Vector LLC extras for teaching data science in Python 3
https://github.com/WinVector/wvpy



