__docformat__ = "restructuredtext"
__version__ = "0.3.7"

__doc__ = """
This<https://github.com/WinVector/wvpy> is a package of example files for teaching data science.
"""
